#ifndef UTILITY_H_
#define UTILITY_H_

void printfArgs(int *firstFlag, char *format, ...);

#endif